package FitPlan.service;

public class AssistantService {
    
}
