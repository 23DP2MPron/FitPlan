package FitPlan.repository;

public class WorkoutRepository {
    
}
