package model;

public class MacroResult {
    
}
