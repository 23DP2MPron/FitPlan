package FitPlan.model;

public class Reminder {
    
}
