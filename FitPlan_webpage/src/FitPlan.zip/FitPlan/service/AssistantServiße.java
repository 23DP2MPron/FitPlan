package service;

public class AssistantServiсe {
    
}
