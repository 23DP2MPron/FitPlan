package model;

public class Exercise {
    
}
