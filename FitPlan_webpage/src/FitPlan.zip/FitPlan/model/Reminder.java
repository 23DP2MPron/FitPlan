package model;

public class Reminder {
    
}
