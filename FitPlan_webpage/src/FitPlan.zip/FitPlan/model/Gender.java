package model;

public enum Gender {
    MALE,
    FEMALE,
}

