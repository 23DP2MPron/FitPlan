package FitPlan.model;

public enum Gender {
    MALE,
    FEMALE,
}

