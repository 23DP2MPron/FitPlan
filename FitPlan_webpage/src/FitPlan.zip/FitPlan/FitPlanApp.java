import controller.ConsoleRouter;

public class FitPlanApp {

    public static void main(String[] args) {
        ConsoleRouter router = new ConsoleRouter();
        router.run();
    }
}