package model;

public class Workout {
    
}
