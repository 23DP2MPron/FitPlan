package repository;

public class WorkoutRepository {
    
}
