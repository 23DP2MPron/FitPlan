package FitPlan.view;

public class MainMenu {
    
}
